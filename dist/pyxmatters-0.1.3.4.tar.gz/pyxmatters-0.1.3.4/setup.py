from setuptools import setup

setup(name='pyxmatters',
      version='0.1.3.4',
      description='pyxmatters',
      author="Matt Henry",
      author_email="mhenry@xmatters.com",
      url='http://github.com/matthewhenry1/pyxmatters',
      license='MIT',
      packages=['xmatters','xmatters.rest','xmatters.util'])
